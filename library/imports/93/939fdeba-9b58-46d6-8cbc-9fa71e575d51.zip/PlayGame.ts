import Move from "../base/move/Move";

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    @property
    text: string = 'hello';

    // 第一章背景图
    @property(cc.Node)
    bgNode1: cc.Node = null;

    // 第二张背景图
    @property(cc.Node)
    bgNode2: cc.Node = null

    // 鸭子
    @property(cc.Prefab)
    dark: cc.Prefab = null;

    // 背景图移动速度
    private speed: number = 15;

    // 左侧用户数组
    private leftArr: object[] = [];

    // 左侧没有站位的坐标
    private notLeftArr: object[] = [];

    // 右侧用户数组
    private rightArr: object[] = [];

    // 右侧没有站位的坐标
    private notRightArr: object[] = [];

    onLoad() {
        this.backgroundMove(this.bgNode1, this.bgNode2);

        this.getCanvas()
    }

    start() {

    }

    update(dt: number) {
        this.backgroundMove(this.bgNode1, this.bgNode2);
    }
    /**
     * 
     * @param node1 第一张背景图
     * @param node2 第二章背景图
     */
    private backgroundMove(node1: cc.Node, node2: cc.Node): void {
        node1.y += this.speed;
        node2.y += this.speed;

        if (node1.y >= 1920) {
            node1.y = node1.y - 2 * 1920;
        }
        if (node2.y >= 1920) {
            node2.y = node2.y - 2 * 1920;
        }
    }

    /**
     * 获取屏幕宽高，进行左侧右侧坐标均分
     */
    private  getCanvas():void {
        let x = cc.find("Canvas").width;
        let y = cc.find("Canvas").height;
        let leftX = (x - 10) / 8;
        let leftY = (y) / 12;

        let X: number[] = [], Y: number[] = [], XY: object[] = []

        // xy.push({x:leftX / 2 + i * leftX,y: 550 + (i + 1) * (leftY / 2 )});
        // X.push(leftX / 2 + i * leftX);
        for (let j = 0; j < 12; j++) {
            for (let i = 0; i < 8; i++) {
                // Y.push(550 + (j) * (leftY / 2))
                XY.push({ x: leftX / 2 + i * leftX, y: 600 + j * (leftY / 2) })
            }
        }
        // 大于屏幕一半分配到右边,小于屏幕一半分配到左边
        for (var t = 0; t < XY.length; t++) {
            if (XY[t]["x"] < x / 2) {
                this.leftArr.push(XY[t])
            } else {
                this.rightArr.push(XY[t])
            }
        }

        // cc.log(this.leftArr, this.rightArr, '44444')
        let zindex = 999;
        let move = new Move();
        for (let q = 0; q < 20; q++) {
            let empt = cc.instantiate(this.dark);
            empt.x = Math.random() * 1000;
            empt.y = 2023;
            empt.parent = cc.find("Canvas/center");
            // 初始化动物进入坐标

            move._moveTo(0.1 * q, XY[q]["x"], XY[q]["y"], empt)
            empt.zIndex = 999 - q;
            // 获取用户占用坑位坐标
            this.pitUser(XY[q], this.leftArr, this.leftArr,this.rightArr);
            this.pitUser(XY[q], this.rightArr,this.leftArr, this.rightArr);
           
        }

    }

    /**
     * 获取占用坑位的坐标
     */
    private pitUser(pit: object, arr: object[],leftArr:object[],rightArr:object[]): void {
        let word = cc.find("Canvas").width;
        // cc.log(word,'gggg')
        for (var i = 0; i < arr.length; i++) {
            if (pit["x"] !== arr[i]["x"] && pit["y"] !== arr[i]["y"]) {
                // cc.log(this.leftArr[i],'4444')
                // 将没有占据坑位的坐标push到新数组中
                if (arr[i]["x"] <= cc.find("Canvas").width / 2) {
                    
                    this.notLeftArr.push(arr.splice(i, 1))
                } else {
                    this.notRightArr.push(arr.splice(i, 1))
                }
                // 将没有占据坑位的坐标从数组中删除
                // arr.splice(i, 1);
                // cc.log(arr.splice(i,1))
            }
        }
       cc.log(leftArr,rightArr,'hhh')
        // cc.log(this.notLeftArr, this.notRightArr, 'ggg',this.leftArr,this.rightArr)
    }
}
